-- ============================================================
-- FreelanceFlow · Supabase Setup v2 (proper auth)
-- Run this in Supabase SQL Editor — safe to re-run
-- ============================================================

-- Main data table
create table if not exists ff_data (
  user_id    text primary key,
  data       jsonb not null default '{}',
  updated_at timestamptz default now()
);

-- Email leads table (founder visibility)
create table if not exists ff_leads (
  id         uuid primary key default gen_random_uuid(),
  email      text unique not null,
  name       text,
  province   text,
  currency   text,
  created_at timestamptz default now()
);

-- Enable RLS
alter table ff_data  enable row level security;
alter table ff_leads enable row level security;

-- Drop old permissive policies if they exist
drop policy if exists "anon_all_data"  on ff_data;
drop policy if exists "anon_all_leads" on ff_leads;

-- Proper auth-based RLS: users can only see their own data
create policy "own_data" on ff_data for all
  to authenticated
  using  (auth.uid()::text = user_id)
  with check (auth.uid()::text = user_id);

-- Leads: any authenticated user can insert their own lead
create policy "insert_lead" on ff_leads for insert
  to authenticated with check (true);

-- Founder dashboard view (run as admin in Supabase)
create or replace view founder_dashboard as
select
  user_id,
  data->>'freelancerName'  as name,
  data->>'freelancerEmail' as email,
  data->>'province'        as province,
  data->>'defaultCurrency' as currency,
  data->>'fbrRegistered'   as fbr_registered,
  jsonb_array_length(coalesce(data->'invoices','[]'::jsonb)) as invoices,
  jsonb_array_length(coalesce(data->'clients', '[]'::jsonb)) as clients,
  updated_at
from ff_data
order by updated_at desc;
