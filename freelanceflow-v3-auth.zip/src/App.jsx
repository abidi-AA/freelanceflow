import { useState, useEffect, useCallback, useRef } from "react";
import { createClient } from "@supabase/supabase-js";
import { jsPDF } from "jspdf";
import emailjs from "@emailjs/browser";
import "./App.css";

// ─── Supabase ─────────────────────────────────────────────────────────────────
const SUPA_URL = import.meta.env.VITE_SUPABASE_URL || "";
const SUPA_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY || "";
const supabase = SUPA_URL && SUPA_KEY ? createClient(SUPA_URL, SUPA_KEY) : null;
const DB_READY = Boolean(supabase);

// ─── EmailJS ──────────────────────────────────────────────────────────────────
const EJ_SERVICE  = "YOUR_SERVICE_ID";
const EJ_TEMPLATE = "YOUR_TEMPLATE_ID";
const EJ_KEY      = "YOUR_PUBLIC_KEY";
const EJ_READY    = EJ_SERVICE !== "YOUR_SERVICE_ID";

// ─── App constants ────────────────────────────────────────────────────────────
const DATA_KEY  = "ff_data_v4";
const VISIT_KEY = "ff_first_visit";
const PAY_LINK  = "https://buy.stripe.com/REPLACE_WITH_YOUR_STRIPE_LINK";
const PRO_DAYS  = 30;

// ─── Helpers ──────────────────────────────────────────────────────────────────
function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 8); }
function daysSince(ts) { return (Date.now() - Number(ts)) / 86400000; }
function nextInvNum(invoices) {
  const nums = invoices.map(i => parseInt((i.number || "INV-000").replace("INV-", "")) || 0);
  return "INV-" + String((nums.length ? Math.max(...nums) : 0) + 1).padStart(3, "0");
}

// ─── Cloud sync ───────────────────────────────────────────────────────────────
async function cloudLoad(userId) {
  if (!DB_READY) return null;
  const { data, error } = await supabase.from("ff_data").select("data").eq("user_id", userId).single();
  if (error || !data) return null;
  return data.data;
}

async function cloudSave(userId, appData) {
  if (!DB_READY) return;
  const { error } = await supabase.from("ff_data").upsert(
    { user_id: userId, data: appData, updated_at: new Date().toISOString() },
    { onConflict: "user_id" }
  );
  if (error) throw error;
}

async function cloudSaveLead(lead) {
  if (!DB_READY) return;
  await supabase.from("ff_leads").upsert(lead, { onConflict: "email", ignoreDuplicates: true });
}

// ─── Currency ─────────────────────────────────────────────────────────────────
const CURRENCIES = {
  USD: { symbol: "$",   name: "US Dollar"        },
  EUR: { symbol: "€",   name: "Euro"              },
  GBP: { symbol: "£",   name: "British Pound"     },
  CAD: { symbol: "CA$", name: "Canadian Dollar"   },
  AUD: { symbol: "A$",  name: "Australian Dollar" },
  PKR: { symbol: "Rs ", name: "Pakistani Rupee"   },
};
function fmtC(n, currency = "USD") {
  return (CURRENCIES[currency] || CURRENCIES.USD).symbol + Number(n).toLocaleString("en-PK");
}
function fmtPKR(n) { return "Rs " + Math.round(n).toLocaleString("en-PK"); }

// ─── Province tax ─────────────────────────────────────────────────────────────
const PROVINCES = {
  sindh:       { name: "Sindh",           authority: "SRB",         servicesTax: 13 },
  punjab:      { name: "Punjab",          authority: "PRA",         servicesTax: 16 },
  kpk:         { name: "KPK",             authority: "KPRA",        servicesTax: 15 },
  balochistan: { name: "Balochistan",     authority: "BRA",         servicesTax: 15 },
  ajk:         { name: "AJK",             authority: "AJK Revenue", servicesTax: 0  },
  federal:     { name: "Federal/Unreg.",  authority: "FBR only",    servicesTax: 0  },
};

function calcIncomeTax(pkr) {
  if (pkr <= 600000)  return 0;
  if (pkr <= 1200000) return (pkr - 600000) * 0.05;
  if (pkr <= 2400000) return 30000 + (pkr - 1200000) * 0.15;
  if (pkr <= 3600000) return 210000 + (pkr - 2400000) * 0.25;
  return 510000 + (pkr - 3600000) * 0.35;
}

const PAYMENT_METHODS = ["Wise", "Payoneer", "Bank Transfer (IBAN)", "Remitly", "Other"];
const SL = { paid: "Paid", sent: "Sent", overdue: "Overdue", draft: "Draft" };

const EMPTY = {
  clients: [], invoices: [],
  province: null, defaultCurrency: "USD",
  fbrRegistered: false, ntn: "",
  freelancerName: "", freelancerEmail: "",
  pkrRate: 280, withholdingPaid: 0,
};

// ─── Auth screen ──────────────────────────────────────────────────────────────
function AuthScreen() {
  const [step,    setStep]    = useState("email");
  const [email,   setEmail]   = useState("");
  const [otp,     setOtp]     = useState("");
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState("");

  async function sendOTP() {
    if (!email) return;
    setLoading(true); setError("");
    const { error: e } = await supabase.auth.signInWithOtp({
      email, options: { shouldCreateUser: true },
    });
    if (e) setError(e.message);
    else setStep("otp");
    setLoading(false);
  }

  async function verifyOTP() {
    if (otp.length !== 6) return;
    setLoading(true); setError("");
    const { error: e } = await supabase.auth.verifyOtp({ email, token: otp, type: "email" });
    if (e) setError("Invalid code. Check your email and try again.");
    setLoading(false);
  }

  return (
    <div className="auth-wrap">
      <div className="auth-card">
        <div className="auth-logo">FreelanceFlow 🇵🇰</div>
        <p className="auth-tagline">Pakistan's freelance income tracker for international clients</p>
        <div className="auth-divider" />

        {step === "email" && <>
          <h2 className="auth-title">Sign in or create account</h2>
          <p className="auth-sub">Enter your email — we'll send you a 6-digit code. No password needed.</p>
          <div className="field">
            <label>Email address</label>
            <input
              type="email" className="input" placeholder="you@gmail.com"
              value={email} onChange={e => setEmail(e.target.value)}
              onKeyDown={e => e.key === "Enter" && sendOTP()}
              autoFocus
            />
          </div>
          {error && <div className="error-msg">{error}</div>}
          <button className="btn btn-primary auth-btn" onClick={sendOTP} disabled={loading || !email}>
            {loading ? "Sending code…" : "Continue →"}
          </button>
          <p className="auth-note">Free to use. Your data is encrypted and private.</p>
        </>}

        {step === "otp" && <>
          <h2 className="auth-title">Check your email</h2>
          <p className="auth-sub">We sent a 6-digit code to <strong>{email}</strong>. Enter it below.</p>
          <div className="field">
            <label>Verification code</label>
            <input
              type="text" className="input otp-input" placeholder="000000"
              maxLength={6} value={otp}
              onChange={e => setOtp(e.target.value.replace(/\D/g, ""))}
              onKeyDown={e => e.key === "Enter" && verifyOTP()}
              autoFocus
            />
          </div>
          {error && <div className="error-msg">{error}</div>}
          <button className="btn btn-primary auth-btn" onClick={verifyOTP} disabled={loading || otp.length !== 6}>
            {loading ? "Verifying…" : "Sign in →"}
          </button>
          <button className="btn btn-ghost" style={{ width: "100%", marginTop: 8 }}
            onClick={() => { setStep("email"); setOtp(""); setError(""); }}>
            ← Use different email
          </button>
          <p className="auth-note">Didn't receive it? Check your spam folder or go back and try again.</p>
        </>}
      </div>
    </div>
  );
}

// ─── Onboarding wizard ────────────────────────────────────────────────────────
function OnboardingWizard({ userEmail, onComplete }) {
  const [step, setStep] = useState(1);
  const [vals, setVals] = useState({
    province: "", defaultCurrency: "USD",
    fbrRegistered: false, ntn: "",
    freelancerName: "", freelancerEmail: userEmail || "",
  });

  return (
    <div className="wizard-wrap">
      <div className="wizard-card">
        <div className="wizard-brand">FreelanceFlow 🇵🇰</div>
        <div className="wizard-progress">
          {[1,2,3].map(n => <div key={n} className={`wprog-dot ${step >= n ? "active" : ""}`} />)}
        </div>

        {step === 1 && <>
          <div className="wizard-icon">📍</div>
          <h2 className="wizard-title">Which province are you based in?</h2>
          <p className="wizard-sub">Sets your provincial services tax — SRB, PRA, KPRA etc. Shown on your tax estimate screen.</p>
          <div className="province-grid">
            {Object.entries(PROVINCES).map(([k, p]) => (
              <button key={k} className={`province-btn ${vals.province === k ? "sel" : ""}`}
                onClick={() => setVals({ ...vals, province: k })}>
                <div className="pb-name">{p.name}</div>
                <div className="pb-auth">{p.authority} · {p.servicesTax}%</div>
              </button>
            ))}
          </div>
          <button className="btn btn-primary wizard-cta" disabled={!vals.province} onClick={() => setStep(2)}>
            Continue →
          </button>
        </>}

        {step === 2 && <>
          <div className="wizard-icon">💱</div>
          <h2 className="wizard-title">How do international clients pay you?</h2>
          <p className="wizard-sub">Your primary earning currency. You can choose a different one per invoice.</p>
          <div className="currency-grid">
            {Object.entries(CURRENCIES).filter(([k]) => k !== "PKR").map(([k, c]) => (
              <button key={k} className={`currency-btn ${vals.defaultCurrency === k ? "sel" : ""}`}
                onClick={() => setVals({ ...vals, defaultCurrency: k })}>
                <span className="cb-sym">{c.symbol}{k}</span>
                <span className="cb-name">{c.name}</span>
              </button>
            ))}
          </div>
          <button className="btn btn-primary wizard-cta" onClick={() => setStep(3)}>Continue →</button>
        </>}

        {step === 3 && <>
          <div className="wizard-icon">🪪</div>
          <h2 className="wizard-title">Your invoice profile</h2>
          <p className="wizard-sub">This appears on every invoice you send. Editable anytime in settings.</p>
          <div className="field">
            <label>Full name *</label>
            <input className="input" placeholder="Muhammad Ali" value={vals.freelancerName}
              onChange={e => setVals({ ...vals, freelancerName: e.target.value })} />
          </div>
          <div className="field">
            <label>Invoice email (shown on invoices)</label>
            <input className="input" type="email" placeholder="you@gmail.com" value={vals.freelancerEmail}
              onChange={e => setVals({ ...vals, freelancerEmail: e.target.value })} />
          </div>
          <label className="checkbox-label">
            <input type="checkbox" checked={vals.fbrRegistered}
              onChange={e => setVals({ ...vals, fbrRegistered: e.target.checked })} />
            I am FBR registered (I have an NTN number)
          </label>
          {vals.fbrRegistered && (
            <div className="field" style={{ marginTop: 12 }}>
              <label>NTN Number</label>
              <input className="input" placeholder="1234567-8" value={vals.ntn}
                onChange={e => setVals({ ...vals, ntn: e.target.value })} />
            </div>
          )}
          <button className="btn btn-primary wizard-cta" disabled={!vals.freelancerName}
            onClick={() => onComplete(vals)}>
            Start FreelanceFlow →
          </button>
        </>}
      </div>
    </div>
  );
}

// ─── Small components ─────────────────────────────────────────────────────────
function Badge({ status }) {
  return <span className={`badge badge-${status}`}>{SL[status] || status}</span>;
}

function Modal({ onClose, children }) {
  return (
    <div className="overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">{children}</div>
    </div>
  );
}

function SyncPill({ status }) {
  const map = {
    syncing: { label: "Syncing…",  cls: "sync-amber" },
    synced:  { label: "☁ Synced",  cls: "sync-green" },
    error:   { label: "⚠ Sync err",cls: "sync-red"   },
    offline: { label: "Offline",   cls: "sync-muted"  },
    local:   { label: "Local only",cls: "sync-muted"  },
  };
  const s = map[status] || map.local;
  return <span className={`sync-pill ${s.cls}`}>{s.label}</span>;
}

function UpgradeModal({ onClose }) {
  return (
    <Modal onClose={onClose}>
      <div className="upgrade-modal">
        <div className="upgrade-emoji">⚡</div>
        <div className="upgrade-title">Upgrade to Pro</div>
        <div className="upgrade-sub">You have been using FreelanceFlow for 30 days.<br />Unlock the full product for $15/month.</div>
        <div className="upgrade-list">
          {["Unlimited clients & invoices","CSV export for accountant","Priority cloud backup","PDF invoice download","Priority support"].map(f => (
            <div key={f} className="upgrade-item"><span className="upgrade-check">✓</span><span>{f}</span></div>
          ))}
        </div>
        <a href={PAY_LINK} target="_blank" rel="noopener noreferrer" className="btn btn-purple"
          style={{ width: "100%", justifyContent: "center", fontSize: "15px", padding: "12px" }}>
          Get Pro — $15 / month
        </a>
        <button className="dismiss-btn" onClick={onClose}>Maybe later</button>
      </div>
    </Modal>
  );
}

// ─── Settings modal ───────────────────────────────────────────────────────────
function SettingsModal({ d, persist, userEmail, onSignOut, onClose }) {
  const [form, setForm] = useState({
    freelancerName:  d.freelancerName  || "",
    freelancerEmail: d.freelancerEmail || "",
    fbrRegistered:   d.fbrRegistered   || false,
    ntn:             d.ntn             || "",
    province:        d.province        || "federal",
    defaultCurrency: d.defaultCurrency || "USD",
  });

  function save() { persist({ ...d, ...form }); onClose(); }

  return (
    <Modal onClose={onClose}>
      <div className="modal-title">⚙️ Settings</div>
      <div className="field"><label>Full name</label>
        <input className="input" value={form.freelancerName} onChange={e => setForm({ ...form, freelancerName: e.target.value })} />
      </div>
      <div className="field"><label>Invoice email</label>
        <input className="input" type="email" value={form.freelancerEmail} onChange={e => setForm({ ...form, freelancerEmail: e.target.value })} />
      </div>
      <div className="field"><label>Province</label>
        <select className="input" value={form.province} onChange={e => setForm({ ...form, province: e.target.value })}>
          {Object.entries(PROVINCES).map(([k, p]) => (
            <option key={k} value={k}>{p.name} — {p.authority} ({p.servicesTax}%)</option>
          ))}
        </select>
      </div>
      <div className="field"><label>Default currency</label>
        <select className="input" value={form.defaultCurrency} onChange={e => setForm({ ...form, defaultCurrency: e.target.value })}>
          {Object.entries(CURRENCIES).map(([k, c]) => <option key={k} value={k}>{k} — {c.name}</option>)}
        </select>
      </div>
      <label className="checkbox-label" style={{ marginBottom: 8 }}>
        <input type="checkbox" checked={form.fbrRegistered} onChange={e => setForm({ ...form, fbrRegistered: e.target.checked })} />
        FBR Registered
      </label>
      {form.fbrRegistered && (
        <div className="field"><label>NTN Number</label>
          <input className="input" placeholder="1234567-8" value={form.ntn} onChange={e => setForm({ ...form, ntn: e.target.value })} />
        </div>
      )}
      <div style={{ borderTop: "1px solid var(--border)", marginTop: 16, paddingTop: 16 }}>
        <div style={{ fontSize: 12, color: "var(--text-3)", marginBottom: 8 }}>Signed in as {userEmail}</div>
        <button className="btn btn-ghost" style={{ width: "100%", color: "var(--red)" }} onClick={onSignOut}>Sign out</button>
      </div>
      <div className="modal-footer">
        <button className="btn btn-primary" style={{ flex: 1 }} onClick={save}>Save changes</button>
        <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
      </div>
    </Modal>
  );
}

// ─── Send email modal ─────────────────────────────────────────────────────────
function SendEmailModal({ inv, freelancer, client, onClose }) {
  const [sending, setSending] = useState(false);
  const [sent,    setSent]    = useState(false);
  const [err,     setErr]     = useState("");
  const [msg, setMsg] = useState(
    `Hi ${client?.name || ""},\n\nPlease find invoice ${inv.number} for ${fmtC(inv.amount, inv.currency)} due on ${inv.due}.\n\nKind regards,\n${freelancer.name}`
  );

  async function send() {
    if (!EJ_READY) { setErr("EmailJS not configured. See instructions at top of App.jsx."); return; }
    if (!client?.email) { setErr("No email on file for this client. Edit the client to add one."); return; }
    setSending(true); setErr("");
    try {
      await emailjs.send(EJ_SERVICE, EJ_TEMPLATE, {
        to_email: client.email, to_name: client.name,
        from_name: freelancer.name, from_email: freelancer.email,
        invoice_number: inv.number, amount: fmtC(inv.amount, inv.currency),
        due_date: inv.due, message: msg,
      }, EJ_KEY);
      setSent(true);
    } catch { setErr("Send failed. Check your EmailJS config."); }
    setSending(false);
  }

  return (
    <Modal onClose={onClose}>
      <div className="modal-title">✉️ Send Invoice</div>
      {sent ? (
        <div className="send-success">
          <div style={{ fontSize: 40, marginBottom: 10 }}>✅</div>
          <div style={{ fontWeight: 600, marginBottom: 6 }}>Invoice sent!</div>
          <div style={{ fontSize: 13, color: "var(--text-3)" }}>To {client?.email}</div>
          <button className="btn btn-ghost" style={{ marginTop: 20 }} onClick={onClose}>Done</button>
        </div>
      ) : <>
        <div className="field"><label>To</label>
          <input className="input" value={client?.email || "⚠ No email on file"} readOnly
            style={{ color: client?.email ? "var(--text)" : "var(--red)" }} />
        </div>
        <div className="field"><label>Subject</label>
          <input className="input" readOnly value={`Invoice ${inv.number} — ${fmtC(inv.amount, inv.currency)} due ${inv.due}`} />
        </div>
        <div className="field"><label>Message</label>
          <textarea className="input" rows={6} value={msg} onChange={e => setMsg(e.target.value)} style={{ resize: "vertical" }} />
        </div>
        {!EJ_READY && <div className="ej-notice">⚙️ <strong>EmailJS not configured.</strong> Create a free account at <a href="https://www.emailjs.com" target="_blank" rel="noopener noreferrer">emailjs.com</a>, then update EJ_SERVICE, EJ_TEMPLATE, EJ_KEY at the top of App.jsx.</div>}
        {err && <div className="error-msg">{err}</div>}
        <div className="modal-footer">
          <button className="btn btn-primary" style={{ flex: 1 }} onClick={send} disabled={sending}>
            {sending ? "Sending…" : "Send Invoice"}
          </button>
          <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
        </div>
      </>}
    </Modal>
  );
}

// ─── PDF generator ────────────────────────────────────────────────────────────
function downloadInvoicePDF(inv, freelancer, client) {
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const W = 210;
  doc.setFillColor(15,23,42); doc.rect(0,0,W,42,"F");
  doc.setFont("helvetica","bold"); doc.setFontSize(20); doc.setTextColor(255,255,255);
  doc.text("FreelanceFlow",16,18);
  doc.setFont("helvetica","normal"); doc.setFontSize(9); doc.setTextColor(56,189,248);
  doc.text("INVOICE",16,27);
  doc.setFont("helvetica","bold"); doc.setFontSize(16); doc.setTextColor(255,255,255);
  doc.text(inv.number||"INV-001",W-16,18,{align:"right"});
  doc.setFont("helvetica","normal"); doc.setFontSize(8); doc.setTextColor(148,163,184);
  doc.text(`Issue Date: ${inv.date||"—"}`,W-16,26,{align:"right"});
  doc.text(`Due Date:   ${inv.due||"—"}`,W-16,31,{align:"right"});
  let y=54;
  doc.setFont("helvetica","bold"); doc.setFontSize(7); doc.setTextColor(100,116,139);
  doc.text("FROM",16,y); doc.text("BILL TO",110,y);
  y+=6; doc.setFont("helvetica","bold"); doc.setFontSize(11); doc.setTextColor(15,23,42);
  doc.text(freelancer.name||"—",16,y); doc.text(client?.name||"—",110,y);
  y+=5; doc.setFont("helvetica","normal"); doc.setFontSize(9); doc.setTextColor(71,85,105);
  if(freelancer.email) doc.text(freelancer.email,16,y);
  if(client?.email)    doc.text(client.email,110,y);
  y+=5; doc.text("Pakistan",16,y);
  if(client?.country)  doc.text(client.country,110,y);
  if(freelancer.ntn){y+=5;doc.text(`NTN: ${freelancer.ntn}`,16,y);}
  y+=16; doc.setFillColor(248,250,252); doc.rect(16,y-6,W-32,10,"F");
  doc.setFont("helvetica","bold"); doc.setFontSize(8); doc.setTextColor(100,116,139);
  doc.text("DESCRIPTION",20,y); doc.text("AMOUNT",W-20,y,{align:"right"});
  y+=4; doc.setDrawColor(226,232,240); doc.line(16,y,W-16,y);
  y+=9; doc.setFont("helvetica","normal"); doc.setFontSize(10); doc.setTextColor(15,23,42);
  const dl=doc.splitTextToSize(inv.desc||"Service",W-80); doc.text(dl,20,y);
  doc.setFont("helvetica","bold"); doc.text(fmtC(inv.amount,inv.currency||"USD"),W-20,y,{align:"right"});
  y+=8; doc.line(16,y,W-16,y);
  y+=10; doc.setFontSize(11); doc.setFont("helvetica","bold"); doc.setTextColor(100,116,139);
  doc.text("TOTAL DUE",20,y); doc.setFontSize(15); doc.setTextColor(15,23,42);
  doc.text(fmtC(inv.amount,inv.currency||"USD"),W-20,y,{align:"right"});
  if(inv.paymentMethod){
    y+=16; doc.setFillColor(239,246,255); doc.rect(16,y-6,W-32,16,"F");
    doc.setFont("helvetica","bold"); doc.setFontSize(7); doc.setTextColor(100,116,139);
    doc.text("PAYMENT VIA",20,y); y+=6;
    doc.setFont("helvetica","normal"); doc.setFontSize(10); doc.setTextColor(15,23,42);
    doc.text(inv.paymentMethod,20,y);
  }
  doc.setFillColor(15,23,42); doc.rect(0,278,W,19,"F");
  doc.setFont("helvetica","normal"); doc.setFontSize(8); doc.setTextColor(148,163,184);
  doc.text("Generated by FreelanceFlow · Pakistan's freelance invoice tracker",W/2,287,{align:"center"});
  doc.text("Thank you for your business.",W/2,292,{align:"center"});
  doc.save(`${inv.number||"invoice"}.pdf`);
}

// ─── Main App ─────────────────────────────────────────────────────────────────
export default function App() {
  const [appState, setAppState] = useState("loading"); // loading|auth|onboarding|app
  const [user,     setUser]     = useState(null);
  const [d,        setD]        = useState(null);
  const [syncSt,   setSyncSt]   = useState("local");
  const [tab,      setTab]      = useState("dashboard");
  const [modal,    setModal]    = useState(null);
  const [form,     setForm]     = useState({});
  const [saved,    setSaved]    = useState(false);
  const [filter,   setFilter]   = useState("all");
  const [firstVisit,setFV]      = useState(null);
  const [sendInv,  setSendInv]  = useState(null);
  const syncTimer = useRef(null);

  // ── Load user data from cloud ───────────────────────────────────────────────
  async function loadUserData(userId) {
    setSyncSt("syncing");
    try {
      const cloud = await cloudLoad(userId);
      if (cloud && cloud.province) {
        setD(cloud);
        localStorage.setItem(DATA_KEY, JSON.stringify(cloud));
        setSyncSt("synced");
        setAppState("app");
        return;
      }
    } catch { setSyncSt("offline"); }
    // New user or offline — start fresh or use localStorage cache
    const raw = localStorage.getItem(DATA_KEY);
    const local = raw ? JSON.parse(raw) : { ...EMPTY };
    setD(local);
    setSyncSt(DB_READY ? "error" : "local");
    setAppState(local.province ? "app" : "onboarding");
  }

  // ── Auth state listener ─────────────────────────────────────────────────────
  useEffect(() => {
    let fv = localStorage.getItem(VISIT_KEY);
    if (!fv) { fv = Date.now().toString(); localStorage.setItem(VISIT_KEY, fv); }
    setFV(fv);

    if (!DB_READY) {
      // Local mode — skip auth
      const raw = localStorage.getItem(DATA_KEY);
      const local = raw ? JSON.parse(raw) : { ...EMPTY };
      setD(local);
      setAppState(local.province ? "app" : "onboarding");
      setSyncSt("local");
      return;
    }

    // Auth mode
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (session) {
        setUser(session.user);
        await loadUserData(session.user.id);
      } else {
        setUser(null);
        setD(null);
        setAppState("auth");
        setSyncSt("local");
      }
    });

    // Check initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session) setAppState("auth");
    });

    return () => subscription.unsubscribe();
  }, []);

  // ── Persist ─────────────────────────────────────────────────────────────────
  const persist = useCallback((next) => {
    setD(next);
    try { localStorage.setItem(DATA_KEY, JSON.stringify(next)); } catch {}
    setSaved(true);
    setTimeout(() => setSaved(false), 1800);
    if (DB_READY && user) {
      setSyncSt("syncing");
      clearTimeout(syncTimer.current);
      syncTimer.current = setTimeout(() => {
        cloudSave(user.id, next)
          .then(() => setSyncSt("synced"))
          .catch(() => setSyncSt("error"));
      }, 800);
    }
  }, [user]);

  // ── Sign out ────────────────────────────────────────────────────────────────
  async function signOut() {
    await supabase.auth.signOut();
    localStorage.removeItem(DATA_KEY);
    setModal(null);
  }

  // ── Onboarding complete ─────────────────────────────────────────────────────
  async function onboardingComplete(vals) {
    const next = { ...EMPTY, ...vals };
    persist(next);
    setAppState("app");
    // Save lead for founder visibility
    if (vals.freelancerEmail) {
      cloudSaveLead({
        email: vals.freelancerEmail,
        name: vals.freelancerName,
        province: vals.province,
        currency: vals.defaultCurrency,
      });
    }
  }

  // ── State routing ───────────────────────────────────────────────────────────
  if (appState === "loading")     return <div className="loading">Loading FreelanceFlow…</div>;
  if (appState === "auth")        return <AuthScreen />;
  if (appState === "onboarding")  return <OnboardingWizard userEmail={user?.email} onComplete={onboardingComplete} />;
  if (!d)                         return <div className="loading">Loading your data…</div>;

  // ── Computed values ──────────────────────────────────────────────────────────
  const isProEligible = firstVisit && daysSince(firstVisit) >= PRO_DAYS;
  const prov          = PROVINCES[d.province] || PROVINCES.federal;
  const paid          = d.invoices.filter(i => i.status === "paid");

  const totalPKR = paid.reduce((sum, i) => {
    return i.currency === "PKR" ? sum + i.amount : sum + i.amount * (d.pkrRate || 280);
  }, 0);

  const outstanding    = d.invoices.filter(i => i.status === "sent" || i.status === "overdue");
  const outstandingAmt = outstanding.reduce((s, i) => s + i.amount, 0);
  const outstandingCur = outstanding[0]?.currency || d.defaultCurrency;
  const overdueAmt     = d.invoices.filter(i => i.status === "overdue").reduce((s, i) => s + i.amount, 0);
  const overdueCur     = d.invoices.find(i => i.status === "overdue")?.currency || d.defaultCurrency;

  const servicesTax    = Math.round(totalPKR * prov.servicesTax / 100);
  const monthsElapsed  = new Date().getMonth() + 1;
  const annualPKR      = totalPKR * (12 / monthsElapsed);
  const incomeTaxSoFar = d.fbrRegistered ? Math.round(calcIncomeTax(annualPKR) * monthsElapsed / 12) : 0;
  const withheld       = d.withholdingPaid || 0;
  const totalTaxOwed   = Math.max(0, servicesTax + incomeTaxSoFar - withheld);
  const netPKR         = Math.max(0, Math.round(totalPKR - totalTaxOwed));

  const thisMonth = new Date().toISOString().slice(0, 7);
  const monthPaid = paid.filter(i => (i.date || "").startsWith(thisMonth));
  const monthAmt  = monthPaid.reduce((s, i) => s + i.amount, 0);
  const monthCur  = monthPaid[0]?.currency || d.defaultCurrency;

  const monthlyData = (() => {
    const map = {};
    paid.forEach(i => {
      const m = (i.date || "").slice(0, 7);
      if (m) { const pkr = i.currency === "PKR" ? i.amount : i.amount * (d.pkrRate || 280); map[m] = (map[m] || 0) + pkr; }
    });
    return Object.entries(map).sort((a,b) => a[0].localeCompare(b[0])).map(([m, pkr]) => ({
      label: new Date(m + "-01").toLocaleDateString("en", { month: "short", year: "numeric" }), pkr,
    }));
  })();

  const filteredInvoices = filter === "all" ? d.invoices : d.invoices.filter(i => i.status === filter);
  const isNewUser  = d.clients.length === 0 && d.invoices.length === 0;
  const freelancer = { name: d.freelancerName, email: d.freelancerEmail, ntn: d.ntn };

  const PAGES = { dashboard:"Dashboard", invoices:"Invoices", clients:"Clients", tax:"Tax Estimate" };
  const NAV   = [
    {key:"dashboard",icon:"📊",label:"Dashboard"},
    {key:"invoices", icon:"🧾",label:"Invoices"},
    {key:"clients",  icon:"👤",label:"Clients"},
    {key:"tax",      icon:"📋",label:"Tax"},
  ];

  // ── Actions ──────────────────────────────────────────────────────────────────
  function addInvoice() {
    if (!form.clientId || !form.desc || !form.amount || !form.due) return;
    const client = d.clients.find(c => c.id === form.clientId);
    if (!client) return;
    persist({
      ...d, invoices: [{
        id: uid(), number: nextInvNum(d.invoices),
        clientId: form.clientId, clientName: client.name, clientEmail: client.email || "",
        desc: form.desc, amount: Number(form.amount),
        currency: form.currency || d.defaultCurrency,
        paymentMethod: form.paymentMethod || "",
        due: form.due, status: "draft",
        date: new Date().toISOString().slice(0, 10),
      }, ...d.invoices],
    });
    setModal(null); setForm({});
  }

  function addClient() {
    if (!form.name) return;
    persist({ ...d, clients: [...d.clients, { id: uid(), name: form.name, email: form.email || "", company: form.company || form.name, country: form.country || "" }] });
    setModal(null); setForm({});
  }

  function updateStatus(id, status) { persist({ ...d, invoices: d.invoices.map(i => i.id === id ? { ...i, status } : i) }); }
  function deleteInvoice(id) { persist({ ...d, invoices: d.invoices.filter(i => i.id !== id) }); }
  function deleteClient(id)  { persist({ ...d, clients:  d.clients.filter(c => c.id !== id) }); }

  function exportCSV() {
    const rows = [["Number","Client","Description","Amount","Currency","Payment Method","Due","Status","Created"]];
    d.invoices.forEach(i => rows.push([i.number,i.clientName,i.desc,i.amount,i.currency||d.defaultCurrency,i.paymentMethod||"",i.due,SL[i.status],i.date]));
    const url = URL.createObjectURL(new Blob([rows.map(r => r.map(c => `"${c||""}"`).join(",")).join("\n")], { type: "text/csv" }));
    Object.assign(document.createElement("a"), { href: url, download: "freelanceflow.csv" }).click();
    URL.revokeObjectURL(url);
  }

  // ── Render ────────────────────────────────────────────────────────────────────
  return (
    <div className="shell">

      {/* SIDEBAR */}
      <aside className="sidebar">
        <div className="sidebar-brand">
          <img src="/logo.svg" alt="FreelanceFlow" style={{ width:"100%", borderRadius:"10px", display:"block" }} />
        </div>
        <nav className="sidebar-nav">
          {NAV.map(({ key, icon, label }) => (
            <button key={key} className={`nav-item ${tab === key ? "active" : ""}`} onClick={() => setTab(key)}>
              <span className="nav-icon">{icon}</span>{label}
            </button>
          ))}
        </nav>
        <div className="sidebar-footer">
          <div className="province-badge">{prov.name} · {prov.authority}</div>
          {d.fbrRegistered && <div className="ntn-badge">NTN: {d.ntn || "—"}</div>}
          {DB_READY && <SyncPill status={syncSt} />}
          {user && <div className="user-email-badge">{user.email}</div>}
          <button className="btn btn-ghost btn-sm footer-settings-btn" onClick={() => setModal("settings")}>
            ⚙️ Settings
          </button>
          {isProEligible
            ? <button className="btn btn-purple btn-sm" style={{ width:"100%", marginTop:8 }} onClick={() => setModal("upgrade")}>⚡ Upgrade to Pro</button>
            : <span style={{ fontSize:11, color:"var(--text-3)", marginTop:4, display:"block" }}>Your data syncs automatically</span>
          }
        </div>
      </aside>

      {/* MAIN */}
      <div className="main">
        <header className="topbar">
          <div className="topbar-title">{PAGES[tab]}</div>
          <div className="topbar-actions">
            {saved && <span className="saved">✓ Saved</span>}
            {tab === "invoices" && isProEligible && <button className="btn btn-ghost btn-sm" onClick={exportCSV}>↓ CSV</button>}
            {tab !== "tax" && (
              <button className="btn btn-primary" onClick={() => { setModal(tab === "clients" ? "client" : "invoice"); setForm({ currency: d.defaultCurrency }); }}>
                {tab === "clients" ? "+ Add client" : "+ New invoice"}
              </button>
            )}
          </div>
        </header>

        <div className="page">

          {isNewUser && tab === "dashboard" && (
            <div className="onboarding">
              <div className="onboarding-icon">🌊</div>
              <h1>Welcome to FreelanceFlow</h1>
              <p>Pakistan's freelance income tracker — built for international clients and local tax compliance.</p>
              <div className="onboarding-steps">
                {[["1","Add your first client","The international company or person you work for"],
                  ["2","Create an invoice","Log what you delivered in any currency"],
                  ["3","Mark it paid","Your PKR tax estimate updates in real time"]].map(([n,t,s]) => (
                  <div key={n} className="onboarding-step">
                    <div className="step-num">{n}</div>
                    <div className="step-text"><strong>{t}</strong><span>{s}</span></div>
                  </div>
                ))}
              </div>
              <button className="btn btn-primary" style={{ fontSize:"15px", padding:"12px 28px" }}
                onClick={() => { setModal("client"); setForm({}); }}>
                Add your first client →
              </button>
            </div>
          )}

          {/* DASHBOARD */}
          {tab === "dashboard" && !isNewUser && (
            <>
              <div className="metrics-row">
                {[
                  { label:"Total earned (PKR est.)", val:fmtPKR(totalPKR), sub:`${paid.length} paid invoice${paid.length!==1?"s":""}`, cls:"c-green" },
                  { label:"Outstanding", val:fmtC(outstandingAmt,outstandingCur), sub:`${outstanding.length} awaiting`, cls:"c-amber" },
                  { label:"Overdue", val:fmtC(overdueAmt,overdueCur), sub:`${d.invoices.filter(i=>i.status==="overdue").length} past due`, cls:"c-red" },
                  { label:"Tax owed (PKR est.)", val:fmtPKR(totalTaxOwed), sub:`${prov.name} · ${prov.authority}`, cls:"c-muted" },
                ].map(m => (
                  <div key={m.label} className="metric">
                    <div className="metric-label">{m.label}</div>
                    <div className={`metric-val ${m.cls}`}>{m.val}</div>
                    <div className="metric-sub">{m.sub}</div>
                  </div>
                ))}
              </div>
              <div className="net-card">
                <div><div className="label">Est. net take-home (PKR)</div><div className="val">{fmtPKR(netPKR)}</div></div>
                <div style={{ textAlign:"right" }}><div className="label">This month</div><div className="val-sm">{fmtC(monthAmt,monthCur)}</div></div>
              </div>
              <div className="section-hd">
                <h2>Recent invoices</h2>
                <button className="btn btn-ghost btn-sm" onClick={() => setTab("invoices")}>View all</button>
              </div>
              <div className="table-wrap">
                {d.invoices.length === 0
                  ? <div className="empty"><div className="empty-icon">🧾</div><div className="empty-title">No invoices yet</div>
                      <button className="btn btn-primary" onClick={() => { setModal("invoice"); setForm({ currency:d.defaultCurrency }); }}>+ New invoice</button>
                    </div>
                  : <table>
                      <thead><tr><th>Invoice</th><th>Client</th><th>Description</th><th>Amount</th><th>Due</th><th>Status</th></tr></thead>
                      <tbody>
                        {d.invoices.slice(0,8).map(inv => (
                          <tr key={inv.id}>
                            <td><span className="inv-num">{inv.number||"—"}</span></td>
                            <td className="td-main">{inv.clientName}</td>
                            <td>{inv.desc}</td>
                            <td style={{ fontWeight:600 }}>{fmtC(inv.amount,inv.currency||d.defaultCurrency)}</td>
                            <td style={{ color:"var(--text-3)" }}>{inv.due}</td>
                            <td><Badge status={inv.status}/></td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                }
              </div>
            </>
          )}

          {/* INVOICES */}
          {tab === "invoices" && (
            <>
              <div className="filter-row" style={{ marginBottom:"16px" }}>
                {["all","draft","sent","overdue","paid"].map(s => (
                  <button key={s} className={`filter-btn ${filter===s?"active":""}`} onClick={() => setFilter(s)}>
                    {s==="all"?"All":SL[s]}
                  </button>
                ))}
                <span className="filter-count">{filteredInvoices.length} invoice{filteredInvoices.length!==1?"s":""}</span>
              </div>
              <div className="table-wrap">
                {filteredInvoices.length === 0
                  ? <div className="empty"><div className="empty-icon">🧾</div><div className="empty-title">No {filter!=="all"?filter+" ":""}invoices</div>
                      {filter==="all"&&<button className="btn btn-primary" onClick={()=>{setModal("invoice");setForm({currency:d.defaultCurrency});}}>+ New invoice</button>}
                    </div>
                  : <table>
                      <thead><tr><th>#</th><th>Client</th><th>Description</th><th>Amount</th><th>Due</th><th>Status</th><th></th></tr></thead>
                      <tbody>
                        {filteredInvoices.map(inv => (
                          <tr key={inv.id}>
                            <td><span className="inv-num">{inv.number||"—"}</span></td>
                            <td><div className="td-main">{inv.clientName}</div><div className="td-sub">{inv.date}</div></td>
                            <td>{inv.desc}</td>
                            <td style={{ fontWeight:600 }}>{fmtC(inv.amount,inv.currency||d.defaultCurrency)}</td>
                            <td style={{ color:"var(--text-3)" }}>{inv.due}</td>
                            <td>
                              <select className="status-select" value={inv.status} onChange={e=>updateStatus(inv.id,e.target.value)}>
                                <option value="draft">Draft</option>
                                <option value="sent">Sent</option>
                                <option value="paid">Paid ✓</option>
                                <option value="overdue">Overdue</option>
                              </select>
                            </td>
                            <td>
                              <div className="inv-actions">
                                <button className="btn btn-ghost btn-sm" onClick={()=>downloadInvoicePDF(inv,freelancer,d.clients.find(c=>c.id===inv.clientId))}>↓ PDF</button>
                                <button className="btn btn-ghost btn-sm" onClick={()=>{setSendInv(inv);setModal("send");}}>✉</button>
                                <button className="btn btn-danger" onClick={()=>deleteInvoice(inv.id)}>Del</button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                }
              </div>
            </>
          )}

          {/* CLIENTS */}
          {tab === "clients" && (
            <>
              {d.clients.length === 0
                ? <div className="empty" style={{ paddingTop:"80px" }}>
                    <div className="empty-icon">👤</div>
                    <div className="empty-title">No clients yet</div>
                    <div className="empty-sub">Add your first international client.</div>
                    <button className="btn btn-primary" onClick={()=>{setModal("client");setForm({});}}>+ Add first client</button>
                  </div>
                : <div className="client-grid">
                    {d.clients.map(c => {
                      const cli   = d.invoices.filter(i => i.clientId === c.id);
                      const cPaid = cli.filter(i => i.status === "paid");
                      const cPaidAmt = cPaid.reduce((s,i) => s+i.amount, 0);
                      const cPaidCur = cPaid[0]?.currency || d.defaultCurrency;
                      const cOwed    = cli.filter(i => i.status==="sent"||i.status==="overdue").reduce((s,i)=>s+i.amount,0);
                      const cOwedCur = cli.find(i=>i.status==="sent"||i.status==="overdue")?.currency||d.defaultCurrency;
                      return (
                        <div key={c.id} className="client-card">
                          <div className="client-head">
                            <div className="avatar">{c.name.slice(0,2).toUpperCase()}</div>
                            <div>
                              <div className="client-name">{c.name}</div>
                              <div className="client-email">{c.email||"No email"}</div>
                              {c.country && <div className="client-email">🌍 {c.country}</div>}
                            </div>
                          </div>
                          <div className="client-stats">
                            <span>{cli.length} invoice{cli.length!==1?"s":""}</span>
                            <span style={{ color:"var(--green)", fontWeight:600 }}>{fmtC(cPaidAmt,cPaidCur)} paid</span>
                          </div>
                          {cOwed>0&&<div style={{ fontSize:"12px", color:"var(--amber)", textAlign:"right" }}>{fmtC(cOwed,cOwedCur)} outstanding</div>}
                          <button className="btn btn-danger" style={{ width:"100%", marginTop:"4px" }} onClick={()=>deleteClient(c.id)}>Remove</button>
                        </div>
                      );
                    })}
                    <div className="card client-add-card" onClick={()=>{setModal("client");setForm({});}}>
                      <div className="client-add-icon">+</div><span style={{ fontSize:"13px" }}>Add client</span>
                    </div>
                  </div>
              }
            </>
          )}

          {/* TAX ESTIMATE */}
          {tab === "tax" && (
            <>
              <div className="card card-p" style={{ marginBottom:16 }}>
                <div className="tax-province-header">
                  <div>
                    <div className="metric-label">Your Province</div>
                    <div style={{ fontWeight:700, fontSize:17, marginTop:2 }}>{prov.name}</div>
                    <div style={{ fontSize:12, color:"var(--text-3)" }}>{prov.authority}</div>
                  </div>
                  <div style={{ textAlign:"right" }}>
                    <div className="metric-label">Services Tax Rate</div>
                    <div style={{ fontWeight:800, fontSize:30, color:prov.servicesTax>0?"var(--red)":"var(--green)" }}>{prov.servicesTax}%</div>
                  </div>
                </div>
                {d.fbrRegistered
                  ? <div className="fbr-badge">✓ FBR Registered · NTN: {d.ntn||"—"}</div>
                  : <div style={{ marginTop:10, fontSize:12, color:"var(--text-3)" }}>Not FBR registered — income tax estimate disabled. Register at <a href="https://fbr.gov.pk" target="_blank" rel="noopener noreferrer">fbr.gov.pk</a></div>
                }
              </div>

              <div className="card card-p" style={{ marginBottom:16 }}>
                <h2 style={{ fontSize:13, fontWeight:600, marginBottom:6 }}>PKR Exchange Rate</h2>
                <p style={{ fontSize:12, color:"var(--text-3)", marginBottom:10 }}>Check your bank or Wise. Used to convert your foreign income to PKR for tax estimates.</p>
                <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                  <span style={{ fontSize:13, color:"var(--text-2)" }}>1 {d.defaultCurrency} =</span>
                  <input type="number" className="input" style={{ width:110 }} value={d.pkrRate||280}
                    onChange={e=>persist({...d,pkrRate:Number(e.target.value)})} />
                  <span style={{ fontSize:13, color:"var(--text-2)" }}>PKR</span>
                </div>
              </div>

              <div className="tax-grid" style={{ marginBottom:16 }}>
                {[
                  { label:"Gross Income (PKR est.)", val:fmtPKR(totalPKR), note:`${paid.length} paid invoice${paid.length!==1?"s":""}`, cls:"" },
                  { label:"Services Tax", val:fmtPKR(servicesTax), note:`${prov.servicesTax}% · ${prov.authority}`, cls:"c-red" },
                  { label:"Income Tax (FBR est.)", val:d.fbrRegistered?fmtPKR(incomeTaxSoFar):"N/A", note:d.fbrRegistered?"FBR slabs 2024-25":"Register with FBR to activate", cls:"c-amber" },
                  { label:"Net Take-Home (PKR est.)", val:fmtPKR(netPKR), note:"After all taxes", cls:"c-green" },
                ].map(m => (
                  <div key={m.label} className="metric">
                    <div className="metric-label">{m.label}</div>
                    <div className={`metric-val ${m.cls}`} style={{ fontSize:"22px" }}>{m.val}</div>
                    <div className="metric-sub">{m.note}</div>
                  </div>
                ))}
              </div>

              <div className="card card-p" style={{ marginBottom:16 }}>
                <h2 style={{ fontSize:13, fontWeight:600, marginBottom:6 }}>Withholding Tax Already Deducted</h2>
                <p style={{ fontSize:12, color:"var(--text-3)", marginBottom:10 }}>If clients deducted tax before paying you, enter the PKR total here. It reduces your remaining liability.</p>
                <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                  <span style={{ fontSize:13, color:"var(--text-2)" }}>Rs</span>
                  <input type="number" className="input" style={{ width:140 }} value={d.withholdingPaid||0}
                    onChange={e=>persist({...d,withholdingPaid:Number(e.target.value)})} placeholder="0" />
                </div>
              </div>

              <div className="card card-p" style={{ marginBottom:16 }}>
                <h2 style={{ fontSize:13, fontWeight:600, marginBottom:6 }}>Quarterly FBR Advance Tax</h2>
                <p style={{ fontSize:12, color:"var(--text-3)", marginBottom:8 }}>FBR requires advance tax 4 times a year. Estimated per quarter:</p>
                <div style={{ fontSize:26, fontWeight:800, color:"var(--amber)" }}>{fmtPKR(totalTaxOwed/4)}</div>
                <div style={{ fontSize:11, color:"var(--text-3)", marginTop:4 }}>Consult a tax advisor for exact figures.</div>
              </div>

              {monthlyData.length > 0 && (
                <div className="card card-p">
                  <div className="section-hd"><h2>Monthly Breakdown (PKR)</h2></div>
                  {monthlyData.map(m => (
                    <div key={m.label} className="tax-row">
                      <span style={{ color:"var(--text-2)" }}>{m.label}</span>
                      <div style={{ display:"flex", gap:"16px", flexWrap:"wrap", alignItems:"center" }}>
                        <span className="c-green" style={{ fontWeight:600, fontSize:"13px" }}>{fmtPKR(m.pkr)}</span>
                        <span className="c-red" style={{ fontSize:"12px" }}>−{fmtPKR(Math.round(m.pkr*prov.servicesTax/100))} tax</span>
                        <span style={{ fontWeight:600, fontSize:"13px" }}>{fmtPKR(m.pkr-Math.round(m.pkr*prov.servicesTax/100))} net</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* MOBILE BOTTOM NAV */}
      <nav className="bottom-nav">
        {NAV.map(({ key, icon, label }) => (
          <button key={key} className={`bottom-nav-item ${tab===key?"active":""}`} onClick={() => setTab(key)}>
            <span className="bottom-nav-icon">{icon}</span><span>{label}</span>
          </button>
        ))}
      </nav>

      {/* MODALS */}
      {modal==="upgrade"  && <UpgradeModal onClose={() => setModal(null)} />}
      {modal==="settings" && <SettingsModal d={d} persist={persist} userEmail={user?.email} onSignOut={signOut} onClose={() => setModal(null)} />}
      {modal==="send" && sendInv && (
        <SendEmailModal inv={sendInv} freelancer={freelancer}
          client={d.clients.find(c => c.id === sendInv.clientId)}
          onClose={() => { setModal(null); setSendInv(null); }} />
      )}

      {modal==="invoice" && (
        <Modal onClose={() => { setModal(null); setForm({}); }}>
          <div className="modal-title">New invoice</div>
          {d.clients.length === 0
            ? <div style={{ textAlign:"center", padding:"20px 0" }}>
                <div style={{ fontSize:"32px", marginBottom:"12px" }}>👤</div>
                <p style={{ color:"var(--text-2)", marginBottom:"16px" }}>Add a client first before creating an invoice.</p>
                <button className="btn btn-primary" onClick={() => { setModal("client"); setForm({}); }}>Add a client first</button>
              </div>
            : <>
                <div className="field"><label>Client</label>
                  <select className="input" value={form.clientId||""} onChange={e=>setForm({...form,clientId:e.target.value})}>
                    <option value="">Select client…</option>
                    {d.clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </div>
                <div className="field"><label>Description of service</label>
                  <input className="input" type="text" placeholder="Web development, logo design, etc."
                    value={form.desc||""} onChange={e=>setForm({...form,desc:e.target.value})}/>
                </div>
                <div className="inv-form-row">
                  <div className="field"><label>Amount</label>
                    <input className="input" type="number" placeholder="0" value={form.amount||""} onChange={e=>setForm({...form,amount:e.target.value})}/>
                  </div>
                  <div className="field"><label>Currency</label>
                    <select className="input" value={form.currency||d.defaultCurrency} onChange={e=>setForm({...form,currency:e.target.value})}>
                      {Object.entries(CURRENCIES).map(([k,c]) => <option key={k} value={k}>{k} — {c.name}</option>)}
                    </select>
                  </div>
                </div>
                <div className="field"><label>Payment method</label>
                  <select className="input" value={form.paymentMethod||""} onChange={e=>setForm({...form,paymentMethod:e.target.value})}>
                    <option value="">Select…</option>
                    {PAYMENT_METHODS.map(m => <option key={m} value={m}>{m}</option>)}
                  </select>
                </div>
                <div className="field"><label>Due date</label>
                  <input className="input" type="date" value={form.due||""} onChange={e=>setForm({...form,due:e.target.value})}/>
                </div>
                {form.amount && Number(form.amount)>0 && form.currency!=="PKR" && (
                  <div className="tax-hint">
                    PKR est: <strong>{fmtPKR(Number(form.amount)*(d.pkrRate||280))}</strong>
                    {prov.servicesTax>0&&<> · {prov.authority} tax: <strong style={{color:"var(--red)"}}>{fmtPKR(Math.round(Number(form.amount)*(d.pkrRate||280)*prov.servicesTax/100))}</strong></>}
                  </div>
                )}
                <div className="modal-footer">
                  <button className="btn btn-primary" style={{ flex:1 }} onClick={addInvoice}>Create invoice</button>
                  <button className="btn btn-ghost" onClick={() => { setModal(null); setForm({}); }}>Cancel</button>
                </div>
              </>
          }
        </Modal>
      )}

      {modal==="client" && (
        <Modal onClose={() => { setModal(null); setForm({}); }}>
          <div className="modal-title">Add client</div>
          {[{label:"Name *",field:"name",placeholder:"Acme Inc"},{label:"Email",field:"email",placeholder:"billing@client.com"},{label:"Company",field:"company",placeholder:"Company name"},{label:"Country",field:"country",placeholder:"United States"}].map(f => (
            <div key={f.field} className="field"><label>{f.label}</label>
              <input className="input" placeholder={f.placeholder} value={form[f.field]||""} onChange={e=>setForm({...form,[f.field]:e.target.value})}/>
            </div>
          ))}
          <div className="modal-footer">
            <button className="btn btn-primary" style={{ flex:1 }} onClick={addClient}>Add client</button>
            <button className="btn btn-ghost" onClick={() => { setModal(null); setForm({}); }}>Cancel</button>
          </div>
        </Modal>
      )}
    </div>
  );
}
