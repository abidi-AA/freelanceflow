import { useState, useEffect, useCallback } from "react";
import { jsPDF } from "jspdf";
import emailjs from "@emailjs/browser";
import "./App.css";

// ─── Constants ────────────────────────────────────────────────────────────────
const DATA_KEY  = "ff_data_v4";
const VISIT_KEY = "ff_first_visit";
const PAY_LINK  = "https://buy.stripe.com/REPLACE_WITH_YOUR_STRIPE_LINK";
const PRO_DAYS  = 30;

// Fill these after creating a free account at emailjs.com
const EJ_SERVICE  = "YOUR_SERVICE_ID";
const EJ_TEMPLATE = "YOUR_TEMPLATE_ID";
const EJ_KEY      = "YOUR_PUBLIC_KEY";
const EJ_READY    = EJ_SERVICE !== "YOUR_SERVICE_ID";

// ─── Helpers ──────────────────────────────────────────────────────────────────
function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
function daysSince(ts) { return (Date.now() - Number(ts)) / 86400000; }
function nextInvNum(invoices) {
  const nums = invoices.map(i => parseInt((i.number || "INV-000").replace("INV-", "")) || 0);
  return "INV-" + String((nums.length ? Math.max(...nums) : 0) + 1).padStart(3, "0");
}

// ─── Currency ─────────────────────────────────────────────────────────────────
const CURRENCIES = {
  USD: { symbol: "$",    name: "US Dollar"         },
  EUR: { symbol: "€",    name: "Euro"               },
  GBP: { symbol: "£",    name: "British Pound"      },
  CAD: { symbol: "CA$",  name: "Canadian Dollar"    },
  AUD: { symbol: "A$",   name: "Australian Dollar"  },
  PKR: { symbol: "Rs ",  name: "Pakistani Rupee"    },
};

function fmtC(n, currency = "USD") {
  const sym = (CURRENCIES[currency] || CURRENCIES.USD).symbol;
  return sym + Number(n).toLocaleString("en-PK");
}
function fmtPKR(n) {
  return "Rs " + Math.round(n).toLocaleString("en-PK");
}

// ─── Province Tax Config ──────────────────────────────────────────────────────
const PROVINCES = {
  sindh:       { name: "Sindh",               authority: "SRB",         servicesTax: 13 },
  punjab:      { name: "Punjab",              authority: "PRA",         servicesTax: 16 },
  kpk:         { name: "KPK",                 authority: "KPRA",        servicesTax: 15 },
  balochistan: { name: "Balochistan",         authority: "BRA",         servicesTax: 15 },
  ajk:         { name: "AJK",                 authority: "AJK Revenue", servicesTax: 0  },
  federal:     { name: "Federal/Unreg.",      authority: "FBR only",    servicesTax: 0  },
};

// FBR Income Tax Slabs 2024-25 (annual PKR)
function calcIncomeTax(pkr) {
  if (pkr <= 600000)   return 0;
  if (pkr <= 1200000)  return (pkr - 600000) * 0.05;
  if (pkr <= 2400000)  return 30000 + (pkr - 1200000) * 0.15;
  if (pkr <= 3600000)  return 210000 + (pkr - 2400000) * 0.25;
  return 510000 + (pkr - 3600000) * 0.35;
}

// ─── Payment Methods ──────────────────────────────────────────────────────────
const PAYMENT_METHODS = ["Wise", "Payoneer", "Bank Transfer (IBAN)", "Remitly", "Other"];

// ─── Default State ────────────────────────────────────────────────────────────
const EMPTY = {
  clients: [], invoices: [],
  province: null, defaultCurrency: "USD",
  fbrRegistered: false, ntn: "",
  freelancerName: "", freelancerEmail: "",
  pkrRate: 280, withholdingPaid: 0,
};

const SL = { paid: "Paid", sent: "Sent", overdue: "Overdue", draft: "Draft" };

// ─── Small Components ─────────────────────────────────────────────────────────
function Badge({ status }) {
  return <span className={`badge badge-${status}`}>{SL[status] || status}</span>;
}

function Modal({ onClose, children }) {
  return (
    <div className="overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">{children}</div>
    </div>
  );
}

function UpgradeModal({ onClose }) {
  return (
    <Modal onClose={onClose}>
      <div className="upgrade-modal">
        <div className="upgrade-emoji">⚡</div>
        <div className="upgrade-title">Upgrade to Pro</div>
        <div className="upgrade-sub">You've been using FreelanceFlow for 30 days.<br />Unlock the full product for $15/month.</div>
        <div className="upgrade-list">
          {["Unlimited clients & invoices", "CSV export for accountant", "Cloud backup", "Invoice PDF download", "Priority support"].map(f => (
            <div key={f} className="upgrade-item"><span className="upgrade-check">✓</span><span>{f}</span></div>
          ))}
        </div>
        <a href={PAY_LINK} target="_blank" rel="noopener noreferrer" className="btn btn-purple" style={{ width: "100%", justifyContent: "center", fontSize: "15px", padding: "12px" }}>
          Get Pro — $15 / month
        </a>
        <button className="dismiss-btn" onClick={onClose}>Maybe later</button>
      </div>
    </Modal>
  );
}

// ─── Onboarding Wizard ────────────────────────────────────────────────────────
function OnboardingWizard({ onComplete }) {
  const [step, setStep] = useState(1);
  const [vals, setVals] = useState({
    province: "", defaultCurrency: "USD",
    fbrRegistered: false, ntn: "",
    freelancerName: "", freelancerEmail: "",
  });

  return (
    <div className="wizard-wrap">
      <div className="wizard-card">
        <div className="wizard-brand">FreelanceFlow 🇵🇰</div>
        <div className="wizard-progress">
          {[1,2,3].map(n => <div key={n} className={`wprog-dot ${step >= n ? "active" : ""}`} />)}
        </div>

        {step === 1 && <>
          <div className="wizard-icon">📍</div>
          <h2 className="wizard-title">Which province are you based in?</h2>
          <p className="wizard-sub">This sets your provincial services tax rate applied by SRB, PRA, or KPRA on your freelance income.</p>
          <div className="province-grid">
            {Object.entries(PROVINCES).map(([k, p]) => (
              <button key={k} className={`province-btn ${vals.province === k ? "sel" : ""}`} onClick={() => setVals({ ...vals, province: k })}>
                <div className="pb-name">{p.name}</div>
                <div className="pb-auth">{p.authority} · {p.servicesTax}%</div>
              </button>
            ))}
          </div>
          <button className="btn btn-primary wizard-cta" disabled={!vals.province} onClick={() => setStep(2)}>Continue →</button>
        </>}

        {step === 2 && <>
          <div className="wizard-icon">💱</div>
          <h2 className="wizard-title">How do your international clients pay you?</h2>
          <p className="wizard-sub">Select your primary earning currency. You can choose a different currency per invoice.</p>
          <div className="currency-grid">
            {Object.entries(CURRENCIES).filter(([k]) => k !== "PKR").map(([k, c]) => (
              <button key={k} className={`currency-btn ${vals.defaultCurrency === k ? "sel" : ""}`} onClick={() => setVals({ ...vals, defaultCurrency: k })}>
                <span className="cb-sym">{c.symbol}{k}</span>
                <span className="cb-name">{c.name}</span>
              </button>
            ))}
          </div>
          <button className="btn btn-primary wizard-cta" onClick={() => setStep(3)}>Continue →</button>
        </>}

        {step === 3 && <>
          <div className="wizard-icon">🪪</div>
          <h2 className="wizard-title">Your profile</h2>
          <p className="wizard-sub">This appears on every invoice you send. You can update it anytime.</p>
          <div className="field">
            <label>Your full name *</label>
            <input className="input" placeholder="Muhammad Ali" value={vals.freelancerName} onChange={e => setVals({ ...vals, freelancerName: e.target.value })} />
          </div>
          <div className="field">
            <label>Your email *</label>
            <input className="input" type="email" placeholder="you@gmail.com" value={vals.freelancerEmail} onChange={e => setVals({ ...vals, freelancerEmail: e.target.value })} />
          </div>
          <label className="checkbox-label">
            <input type="checkbox" checked={vals.fbrRegistered} onChange={e => setVals({ ...vals, fbrRegistered: e.target.checked })} />
            I am FBR registered (I have an NTN number)
          </label>
          {vals.fbrRegistered && (
            <div className="field" style={{ marginTop: 12 }}>
              <label>NTN Number</label>
              <input className="input" placeholder="1234567-8" value={vals.ntn} onChange={e => setVals({ ...vals, ntn: e.target.value })} />
            </div>
          )}
          <button className="btn btn-primary wizard-cta" disabled={!vals.freelancerName || !vals.freelancerEmail} onClick={() => onComplete(vals)}>
            Start FreelanceFlow →
          </button>
          <button className="btn btn-ghost" style={{ width: "100%", marginTop: 8 }} onClick={() => onComplete({ ...vals, freelancerName: vals.freelancerName || "Freelancer", freelancerEmail: vals.freelancerEmail || "" })}>
            Skip for now
          </button>
        </>}
      </div>
    </div>
  );
}

// ─── PDF Generator ────────────────────────────────────────────────────────────
function downloadInvoicePDF(inv, freelancer, client) {
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const W = 210;

  // Header
  doc.setFillColor(15, 23, 42);
  doc.rect(0, 0, W, 42, "F");

  doc.setFont("helvetica", "bold");
  doc.setFontSize(20);
  doc.setTextColor(255, 255, 255);
  doc.text("FreelanceFlow", 16, 18);

  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.setTextColor(56, 189, 248);
  doc.text("INVOICE", 16, 27);

  // Invoice number + dates (right)
  doc.setFont("helvetica", "bold");
  doc.setFontSize(16);
  doc.setTextColor(255, 255, 255);
  doc.text(inv.number || "INV-001", W - 16, 18, { align: "right" });
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.setTextColor(148, 163, 184);
  doc.text(`Issue Date: ${inv.date || "—"}`, W - 16, 26, { align: "right" });
  doc.text(`Due Date:   ${inv.due || "—"}`, W - 16, 31, { align: "right" });

  // FROM / TO
  let y = 54;
  doc.setFont("helvetica", "bold");
  doc.setFontSize(7);
  doc.setTextColor(100, 116, 139);
  doc.text("FROM", 16, y);
  doc.text("BILL TO", 110, y);

  y += 6;
  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.setTextColor(15, 23, 42);
  doc.text(freelancer.name || "—", 16, y);
  doc.text(client?.name || "—", 110, y);

  y += 5;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.setTextColor(71, 85, 105);
  if (freelancer.email) doc.text(freelancer.email, 16, y);
  if (client?.email)    doc.text(client.email, 110, y);
  y += 5;
  doc.text("Pakistan", 16, y);
  if (client?.country)  doc.text(client.country, 110, y);
  if (freelancer.ntn) { y += 5; doc.text(`NTN: ${freelancer.ntn}`, 16, y); }

  // Services table
  y += 16;
  doc.setFillColor(248, 250, 252);
  doc.rect(16, y - 6, W - 32, 10, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text("DESCRIPTION", 20, y);
  doc.text("AMOUNT", W - 20, y, { align: "right" });

  y += 4;
  doc.setDrawColor(226, 232, 240);
  doc.line(16, y, W - 16, y);

  y += 9;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  doc.setTextColor(15, 23, 42);
  // Word wrap description if long
  const descLines = doc.splitTextToSize(inv.desc || "Service", W - 80);
  doc.text(descLines, 20, y);
  doc.setFont("helvetica", "bold");
  doc.text(fmtC(inv.amount, inv.currency || "USD"), W - 20, y, { align: "right" });

  y += 8;
  doc.setDrawColor(226, 232, 240);
  doc.line(16, y, W - 16, y);

  // Total
  y += 10;
  doc.setFontSize(11);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(100, 116, 139);
  doc.text("TOTAL DUE", 20, y);
  doc.setFontSize(15);
  doc.setTextColor(15, 23, 42);
  doc.text(fmtC(inv.amount, inv.currency || "USD"), W - 20, y, { align: "right" });

  // Payment info box
  if (inv.paymentMethod) {
    y += 16;
    doc.setFillColor(239, 246, 255);
    doc.rect(16, y - 6, W - 32, 16, "F");
    doc.setFont("helvetica", "bold");
    doc.setFontSize(7);
    doc.setTextColor(100, 116, 139);
    doc.text("PAYMENT VIA", 20, y);
    y += 6;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(10);
    doc.setTextColor(15, 23, 42);
    doc.text(inv.paymentMethod, 20, y);
  }

  // Footer
  doc.setFillColor(15, 23, 42);
  doc.rect(0, 278, W, 19, "F");
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.setTextColor(148, 163, 184);
  doc.text("Generated by FreelanceFlow · Pakistan's freelance invoice tracker", W / 2, 287, { align: "center" });
  doc.text("Thank you for your business.", W / 2, 292, { align: "center" });

  doc.save(`${inv.number || "invoice"}.pdf`);
}

// ─── Send Email Modal ─────────────────────────────────────────────────────────
function SendEmailModal({ inv, freelancer, client, onClose }) {
  const [sending, setSending] = useState(false);
  const [sent,    setSent]    = useState(false);
  const [err,     setErr]     = useState("");
  const [msg, setMsg] = useState(
    `Hi ${client?.name || ""},\n\nPlease find attached invoice ${inv.number} for ${fmtC(inv.amount, inv.currency)} due on ${inv.due}.\n\nKind regards,\n${freelancer.name}`
  );

  async function send() {
    if (!EJ_READY) { setErr("EmailJS is not configured yet. See the notice below."); return; }
    if (!client?.email) { setErr("This client has no email on file. Edit the client to add one."); return; }
    setSending(true); setErr("");
    try {
      await emailjs.send(EJ_SERVICE, EJ_TEMPLATE, {
        to_email: client.email, to_name: client.name,
        from_name: freelancer.name, from_email: freelancer.email,
        invoice_number: inv.number,
        amount: fmtC(inv.amount, inv.currency),
        due_date: inv.due, message: msg,
      }, EJ_KEY);
      setSent(true);
    } catch {
      setErr("Send failed. Check your EmailJS config and try again.");
    }
    setSending(false);
  }

  return (
    <Modal onClose={onClose}>
      <div className="modal-title">✉️ Send Invoice</div>
      {sent ? (
        <div className="send-success">
          <div style={{ fontSize: 40, marginBottom: 10 }}>✅</div>
          <div style={{ fontWeight: 600, marginBottom: 6 }}>Invoice sent!</div>
          <div style={{ fontSize: 13, color: "var(--text-3)" }}>Sent to {client?.email}</div>
          <button className="btn btn-ghost" style={{ marginTop: 20 }} onClick={onClose}>Done</button>
        </div>
      ) : <>
        <div className="field">
          <label>To</label>
          <input className="input" value={client?.email || "⚠ No email on file — edit client to add one"} readOnly style={{ color: client?.email ? "var(--text)" : "var(--red)" }} />
        </div>
        <div className="field">
          <label>Subject</label>
          <input className="input" readOnly value={`Invoice ${inv.number} — ${fmtC(inv.amount, inv.currency)} due ${inv.due}`} />
        </div>
        <div className="field">
          <label>Message</label>
          <textarea className="input" rows={6} value={msg} onChange={e => setMsg(e.target.value)} style={{ resize: "vertical" }} />
        </div>
        {!EJ_READY && (
          <div className="ej-notice">
            ⚙️ <strong>EmailJS not configured yet.</strong> Create a free account at{" "}
            <a href="https://www.emailjs.com" target="_blank" rel="noopener noreferrer">emailjs.com</a>,
            then replace EJ_SERVICE, EJ_TEMPLATE, and EJ_KEY at the top of App.jsx.
          </div>
        )}
        {err && <div className="error-msg">{err}</div>}
        <div className="modal-footer">
          <button className="btn btn-primary" style={{ flex: 1 }} onClick={send} disabled={sending}>
            {sending ? "Sending…" : "Send Invoice"}
          </button>
          <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
        </div>
      </>}
    </Modal>
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────────
export default function App() {
  const [d, setD]           = useState(null);
  const [tab, setTab]       = useState("dashboard");
  const [modal, setModal]   = useState(null);
  const [form, setForm]     = useState({});
  const [saved, setSaved]   = useState(false);
  const [filter, setFilter] = useState("all");
  const [firstVisit, setFV] = useState(null);
  const [sendInv, setSendInv] = useState(null);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(DATA_KEY);
      setD(raw ? JSON.parse(raw) : { ...EMPTY });
    } catch { setD({ ...EMPTY }); }
    let fv = localStorage.getItem(VISIT_KEY);
    if (!fv) { fv = Date.now().toString(); localStorage.setItem(VISIT_KEY, fv); }
    setFV(fv);
  }, []);

  const persist = useCallback(next => {
    setD(next);
    try { localStorage.setItem(DATA_KEY, JSON.stringify(next)); } catch {}
    setSaved(true);
    setTimeout(() => setSaved(false), 1800);
  }, []);

  if (!d) return <div className="loading">Loading FreelanceFlow…</div>;

  // Show onboarding wizard if province not set yet
  if (!d.province) {
    return <OnboardingWizard onComplete={vals => persist({ ...d, ...vals })} />;
  }

  // ── Computed values ──────────────────────────────────────────────────────────
  const isProEligible = firstVisit && daysSince(firstVisit) >= PRO_DAYS;
  const prov          = PROVINCES[d.province] || PROVINCES.federal;
  const paid          = d.invoices.filter(i => i.status === "paid");

  // PKR equivalent of all paid invoices using stored exchange rate
  const totalPKR = paid.reduce((sum, i) => {
    const amt = i.amount || 0;
    return i.currency === "PKR" ? sum + amt : sum + amt * (d.pkrRate || 280);
  }, 0);

  const outstanding    = d.invoices.filter(i => i.status === "sent" || i.status === "overdue");
  const outstandingAmt = outstanding.reduce((s, i) => s + i.amount, 0);
  const outstandingCur = outstanding[0]?.currency || d.defaultCurrency;
  const overdueAmt     = d.invoices.filter(i => i.status === "overdue").reduce((s, i) => s + i.amount, 0);
  const overdueCur     = d.invoices.find(i => i.status === "overdue")?.currency || d.defaultCurrency;

  // Tax
  const servicesTax     = Math.round(totalPKR * prov.servicesTax / 100);
  const monthsElapsed   = new Date().getMonth() + 1;
  const annualPKR       = totalPKR * (12 / monthsElapsed);
  const incomeTaxAnnual = d.fbrRegistered ? calcIncomeTax(annualPKR) : 0;
  const incomeTaxSoFar  = Math.round(incomeTaxAnnual * monthsElapsed / 12);
  const withheld        = d.withholdingPaid || 0;
  const totalTaxOwed    = Math.max(0, servicesTax + incomeTaxSoFar - withheld);
  const netPKR          = Math.max(0, Math.round(totalPKR - totalTaxOwed));

  const thisMonth   = new Date().toISOString().slice(0, 7);
  const monthPaid   = paid.filter(i => (i.date || "").startsWith(thisMonth));
  const monthAmt    = monthPaid.reduce((s, i) => s + i.amount, 0);
  const monthCur    = monthPaid[0]?.currency || d.defaultCurrency;

  // Monthly PKR breakdown for tax screen
  const monthlyData = (() => {
    const map = {};
    paid.forEach(i => {
      const m = (i.date || "").slice(0, 7);
      if (m) { const pkr = i.currency === "PKR" ? i.amount : i.amount * (d.pkrRate || 280); map[m] = (map[m] || 0) + pkr; }
    });
    return Object.entries(map).sort((a, b) => a[0].localeCompare(b[0])).map(([m, pkr]) => ({
      label: new Date(m + "-01").toLocaleDateString("en", { month: "short", year: "numeric" }), pkr,
    }));
  })();

  const filteredInvoices = filter === "all" ? d.invoices : d.invoices.filter(i => i.status === filter);
  const isNewUser = d.clients.length === 0 && d.invoices.length === 0;
  const freelancer = { name: d.freelancerName, email: d.freelancerEmail, ntn: d.ntn };

  // ── Actions ──────────────────────────────────────────────────────────────────
  function addInvoice() {
    if (!form.clientId || !form.desc || !form.amount || !form.due) return;
    const client = d.clients.find(c => c.id === form.clientId);
    if (!client) return;
    persist({
      ...d, invoices: [{
        id: uid(), number: nextInvNum(d.invoices),
        clientId: form.clientId, clientName: client.name, clientEmail: client.email || "",
        desc: form.desc, amount: Number(form.amount),
        currency: form.currency || d.defaultCurrency,
        paymentMethod: form.paymentMethod || "",
        due: form.due, status: "draft",
        date: new Date().toISOString().slice(0, 10),
      }, ...d.invoices],
    });
    setModal(null); setForm({});
  }

  function addClient() {
    if (!form.name) return;
    persist({ ...d, clients: [...d.clients, { id: uid(), name: form.name, email: form.email || "", company: form.company || form.name, country: form.country || "" }] });
    setModal(null); setForm({});
  }

  function updateStatus(id, status) { persist({ ...d, invoices: d.invoices.map(i => i.id === id ? { ...i, status } : i) }); }
  function deleteInvoice(id) { persist({ ...d, invoices: d.invoices.filter(i => i.id !== id) }); }
  function deleteClient(id)  { persist({ ...d, clients:  d.clients.filter(c => c.id !== id) }); }

  function exportCSV() {
    const rows = [["Number","Client","Description","Amount","Currency","Payment Method","Due","Status","Created"]];
    d.invoices.forEach(i => rows.push([i.number,i.clientName,i.desc,i.amount,i.currency||d.defaultCurrency,i.paymentMethod||"",i.due,SL[i.status],i.date]));
    const url = URL.createObjectURL(new Blob([rows.map(r=>r.map(c=>`"${c||""}"`).join(",")).join("\n")],{type:"text/csv"}));
    Object.assign(document.createElement("a"),{href:url,download:"freelanceflow.csv"}).click();
    URL.revokeObjectURL(url);
  }

  const PAGES = { dashboard:"Dashboard", invoices:"Invoices", clients:"Clients", tax:"Tax Estimate" };
  const NAV   = [{key:"dashboard",icon:"📊",label:"Dashboard"},{key:"invoices",icon:"🧾",label:"Invoices"},{key:"clients",icon:"👤",label:"Clients"},{key:"tax",icon:"📋",label:"Tax"}];

  // ── Render ────────────────────────────────────────────────────────────────────
  return (
    <div className="shell">

      {/* SIDEBAR */}
      <aside className="sidebar">
        <div className="sidebar-brand">
          <img src="/logo.svg" alt="FreelanceFlow" style={{ width:"100%", borderRadius:"10px", display:"block" }} />
        </div>
        <nav className="sidebar-nav">
          {NAV.map(({key,icon,label}) => (
            <button key={key} className={`nav-item ${tab===key?"active":""}`} onClick={()=>setTab(key)}>
              <span className="nav-icon">{icon}</span>{label}
            </button>
          ))}
        </nav>
        <div className="sidebar-footer">
          <div className="province-badge">{prov.name} · {prov.authority}</div>
          {d.fbrRegistered && <div className="ntn-badge">NTN: {d.ntn || "—"}</div>}
          {isProEligible
            ? <button className="btn btn-purple btn-sm" style={{width:"100%",marginTop:8}} onClick={()=>setModal("upgrade")}>⚡ Upgrade to Pro</button>
            : <span style={{fontSize:11,color:"var(--text-3)",marginTop:6,display:"block"}}>Data saved locally</span>}
        </div>
      </aside>

      {/* MAIN */}
      <div className="main">
        <header className="topbar">
          <div className="topbar-title">{PAGES[tab]}</div>
          <div className="topbar-actions">
            {saved && <span className="saved">✓ Saved</span>}
            {tab==="invoices" && isProEligible && <button className="btn btn-ghost btn-sm" onClick={exportCSV}>↓ CSV</button>}
            {tab!=="tax" && (
              <button className="btn btn-primary" onClick={()=>{ setModal(tab==="clients"?"client":"invoice"); setForm({currency:d.defaultCurrency}); }}>
                {tab==="clients"?"+ Add client":"+ New invoice"}
              </button>
            )}
          </div>
        </header>

        <div className="page">

          {/* ONBOARDING EMPTY STATE */}
          {isNewUser && tab==="dashboard" && (
            <div className="onboarding">
              <div className="onboarding-icon">🌊</div>
              <h1>Welcome to FreelanceFlow</h1>
              <p>Pakistan's freelance income tracker — built for international clients and local tax compliance.</p>
              <div className="onboarding-steps">
                {[
                  ["1","Add your first client","The international company or person you work for"],
                  ["2","Create an invoice","Log what you delivered, in any currency"],
                  ["3","Mark it paid","Your PKR tax estimate updates in real time"],
                ].map(([n,title,sub])=>(
                  <div key={n} className="onboarding-step">
                    <div className="step-num">{n}</div>
                    <div className="step-text"><strong>{title}</strong><span>{sub}</span></div>
                  </div>
                ))}
              </div>
              <button className="btn btn-primary" style={{fontSize:"15px",padding:"12px 28px"}} onClick={()=>{ setModal("client"); setForm({}); }}>
                Add your first client →
              </button>
            </div>
          )}

          {/* DASHBOARD */}
          {tab==="dashboard" && !isNewUser && (
            <>
              <div className="metrics-row">
                {[
                  {label:"Total earned (PKR est.)", val:fmtPKR(totalPKR),          sub:`${paid.length} paid invoice${paid.length!==1?"s":""}`, cls:"c-green"},
                  {label:"Outstanding",             val:fmtC(outstandingAmt,outstandingCur), sub:`${outstanding.length} awaiting`,              cls:"c-amber"},
                  {label:"Overdue",                 val:fmtC(overdueAmt,overdueCur),         sub:`${d.invoices.filter(i=>i.status==="overdue").length} past due`, cls:"c-red"},
                  {label:"Tax owed (PKR est.)",     val:fmtPKR(totalTaxOwed),       sub:`${prov.name} · ${prov.authority}`,                     cls:"c-muted"},
                ].map(m=>(
                  <div key={m.label} className="metric">
                    <div className="metric-label">{m.label}</div>
                    <div className={`metric-val ${m.cls}`}>{m.val}</div>
                    <div className="metric-sub">{m.sub}</div>
                  </div>
                ))}
              </div>
              <div className="net-card">
                <div>
                  <div className="label">Est. net take-home (PKR)</div>
                  <div className="val">{fmtPKR(netPKR)}</div>
                </div>
                <div style={{textAlign:"right"}}>
                  <div className="label">This month</div>
                  <div className="val-sm">{fmtC(monthAmt, monthCur)}</div>
                </div>
              </div>
              <div className="section-hd">
                <h2>Recent invoices</h2>
                <button className="btn btn-ghost btn-sm" onClick={()=>setTab("invoices")}>View all</button>
              </div>
              <div className="table-wrap">
                {d.invoices.length===0
                  ? <div className="empty"><div className="empty-icon">🧾</div><div className="empty-title">No invoices yet</div><button className="btn btn-primary" onClick={()=>{ setModal("invoice"); setForm({currency:d.defaultCurrency}); }}>+ New invoice</button></div>
                  : <table>
                      <thead><tr><th>Invoice</th><th>Client</th><th>Description</th><th>Amount</th><th>Due</th><th>Status</th></tr></thead>
                      <tbody>
                        {d.invoices.slice(0,8).map(inv=>(
                          <tr key={inv.id}>
                            <td><span className="inv-num">{inv.number||"—"}</span></td>
                            <td className="td-main">{inv.clientName}</td>
                            <td>{inv.desc}</td>
                            <td style={{fontWeight:600}}>{fmtC(inv.amount, inv.currency||d.defaultCurrency)}</td>
                            <td style={{color:"var(--text-3)"}}>{inv.due}</td>
                            <td><Badge status={inv.status}/></td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                }
              </div>
            </>
          )}

          {/* INVOICES */}
          {tab==="invoices" && (
            <>
              <div className="filter-row" style={{marginBottom:"16px"}}>
                {["all","draft","sent","overdue","paid"].map(s=>(
                  <button key={s} className={`filter-btn ${filter===s?"active":""}`} onClick={()=>setFilter(s)}>
                    {s==="all"?"All":SL[s]}
                  </button>
                ))}
                <span className="filter-count">{filteredInvoices.length} invoice{filteredInvoices.length!==1?"s":""}</span>
              </div>
              <div className="table-wrap">
                {filteredInvoices.length===0
                  ? <div className="empty"><div className="empty-icon">🧾</div><div className="empty-title">No {filter!=="all"?filter+" ":""}invoices</div>{filter==="all"&&<button className="btn btn-primary" onClick={()=>{ setModal("invoice"); setForm({currency:d.defaultCurrency}); }}>+ New invoice</button>}</div>
                  : <table>
                      <thead><tr><th>#</th><th>Client</th><th>Description</th><th>Amount</th><th>Due</th><th>Status</th><th></th></tr></thead>
                      <tbody>
                        {filteredInvoices.map(inv=>(
                          <tr key={inv.id}>
                            <td><span className="inv-num">{inv.number||"—"}</span></td>
                            <td><div className="td-main">{inv.clientName}</div><div className="td-sub">{inv.date}</div></td>
                            <td>{inv.desc}</td>
                            <td style={{fontWeight:600}}>{fmtC(inv.amount, inv.currency||d.defaultCurrency)}</td>
                            <td style={{color:"var(--text-3)"}}>{inv.due}</td>
                            <td>
                              <select className="status-select" value={inv.status} onChange={e=>updateStatus(inv.id,e.target.value)}>
                                <option value="draft">Draft</option>
                                <option value="sent">Sent</option>
                                <option value="paid">Paid ✓</option>
                                <option value="overdue">Overdue</option>
                              </select>
                            </td>
                            <td>
                              <div className="inv-actions">
                                <button className="btn btn-ghost btn-sm" onClick={()=>downloadInvoicePDF(inv,freelancer,d.clients.find(c=>c.id===inv.clientId))}>↓ PDF</button>
                                <button className="btn btn-ghost btn-sm" onClick={()=>{ setSendInv(inv); setModal("send"); }}>✉ Send</button>
                                <button className="btn btn-danger" onClick={()=>deleteInvoice(inv.id)}>Del</button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                }
              </div>
            </>
          )}

          {/* CLIENTS */}
          {tab==="clients" && (
            <>
              {d.clients.length===0
                ? <div className="empty" style={{paddingTop:"80px"}}><div className="empty-icon">👤</div><div className="empty-title">No clients yet</div><div className="empty-sub">Add your first international client to start creating invoices.</div><button className="btn btn-primary" onClick={()=>{ setModal("client"); setForm({}); }}>+ Add first client</button></div>
                : <div className="client-grid">
                    {d.clients.map(c=>{
                      const cli=d.invoices.filter(i=>i.clientId===c.id);
                      const cPaid=cli.filter(i=>i.status==="paid");
                      const cPaidAmt=cPaid.reduce((s,i)=>s+i.amount,0);
                      const cPaidCur=cPaid[0]?.currency||d.defaultCurrency;
                      const cOwed=cli.filter(i=>i.status==="sent"||i.status==="overdue").reduce((s,i)=>s+i.amount,0);
                      const cOwedCur=cli.find(i=>i.status==="sent"||i.status==="overdue")?.currency||d.defaultCurrency;
                      return (
                        <div key={c.id} className="client-card">
                          <div className="client-head">
                            <div className="avatar">{c.name.slice(0,2).toUpperCase()}</div>
                            <div>
                              <div className="client-name">{c.name}</div>
                              <div className="client-email">{c.email||"No email"}</div>
                              {c.country&&<div className="client-email">🌍 {c.country}</div>}
                            </div>
                          </div>
                          <div className="client-stats">
                            <span>{cli.length} invoice{cli.length!==1?"s":""}</span>
                            <span style={{color:"var(--green)",fontWeight:600}}>{fmtC(cPaidAmt,cPaidCur)} paid</span>
                          </div>
                          {cOwed>0&&<div style={{fontSize:"12px",color:"var(--amber)",textAlign:"right"}}>{fmtC(cOwed,cOwedCur)} outstanding</div>}
                          <button className="btn btn-danger" style={{width:"100%",marginTop:"4px"}} onClick={()=>deleteClient(c.id)}>Remove</button>
                        </div>
                      );
                    })}
                    <div className="card client-add-card" onClick={()=>{ setModal("client"); setForm({}); }}>
                      <div className="client-add-icon">+</div><span style={{fontSize:"13px"}}>Add client</span>
                    </div>
                  </div>
              }
            </>
          )}

          {/* TAX ESTIMATE */}
          {tab==="tax" && (
            <>
              {/* Province info card */}
              <div className="card card-p" style={{marginBottom:16}}>
                <div className="tax-province-header">
                  <div>
                    <div className="metric-label">Your Province</div>
                    <div style={{fontWeight:700,fontSize:17,marginTop:2}}>{prov.name}</div>
                    <div style={{fontSize:12,color:"var(--text-3)"}}>{prov.authority}</div>
                  </div>
                  <div style={{textAlign:"right"}}>
                    <div className="metric-label">Services Tax Rate</div>
                    <div style={{fontWeight:800,fontSize:30,color:prov.servicesTax>0?"var(--red)":"var(--green)"}}>{prov.servicesTax}%</div>
                  </div>
                </div>
                {d.fbrRegistered&&<div className="fbr-badge">✓ FBR Registered · NTN: {d.ntn||"—"}</div>}
                {!d.fbrRegistered&&<div style={{marginTop:10,fontSize:12,color:"var(--text-3)"}}>Not FBR registered — income tax estimate not shown. Register at <a href="https://fbr.gov.pk" target="_blank" rel="noopener noreferrer">fbr.gov.pk</a> to activate.</div>}
              </div>

              {/* Exchange rate */}
              <div className="card card-p" style={{marginBottom:16}}>
                <h2 style={{fontSize:13,fontWeight:600,marginBottom:6}}>PKR Exchange Rate</h2>
                <p style={{fontSize:12,color:"var(--text-3)",marginBottom:10}}>Check your bank or Wise for today's rate. Used to estimate your PKR income and tax liability.</p>
                <div style={{display:"flex",alignItems:"center",gap:10}}>
                  <span style={{fontSize:13,color:"var(--text-2)"}}>1 {d.defaultCurrency} =</span>
                  <input type="number" className="input" style={{width:110}} value={d.pkrRate||280} onChange={e=>persist({...d,pkrRate:Number(e.target.value)})} />
                  <span style={{fontSize:13,color:"var(--text-2)"}}>PKR</span>
                </div>
              </div>

              {/* Tax metrics grid */}
              <div className="tax-grid" style={{marginBottom:16}}>
                {[
                  {label:"Gross Income (PKR est.)",  val:fmtPKR(totalPKR),        note:`${paid.length} paid invoice${paid.length!==1?"s":""}·${d.pkrRate} rate`,  cls:""},
                  {label:"Services Tax",              val:fmtPKR(servicesTax),     note:`${prov.servicesTax}% · ${prov.authority}`,                                  cls:"c-red"},
                  {label:"Income Tax (FBR est.)",     val:d.fbrRegistered?fmtPKR(incomeTaxSoFar):"N/A", note:d.fbrRegistered?"Based on FBR 2024-25 slabs":"Not FBR registered", cls:"c-amber"},
                  {label:"Net Take-Home (PKR est.)",  val:fmtPKR(netPKR),          note:"After services + income tax",                                               cls:"c-green"},
                ].map(m=>(
                  <div key={m.label} className="metric">
                    <div className="metric-label">{m.label}</div>
                    <div className={`metric-val ${m.cls}`} style={{fontSize:"22px"}}>{m.val}</div>
                    <div className="metric-sub">{m.note}</div>
                  </div>
                ))}
              </div>

              {/* Withholding tax */}
              <div className="card card-p" style={{marginBottom:16}}>
                <h2 style={{fontSize:13,fontWeight:600,marginBottom:6}}>Withholding Tax Already Deducted</h2>
                <p style={{fontSize:12,color:"var(--text-3)",marginBottom:10}}>If clients have deducted tax at source before paying you, enter the PKR total here. This reduces your remaining tax liability.</p>
                <div style={{display:"flex",alignItems:"center",gap:10}}>
                  <span style={{fontSize:13,color:"var(--text-2)"}}>Rs</span>
                  <input type="number" className="input" style={{width:140}} value={d.withholdingPaid||0} onChange={e=>persist({...d,withholdingPaid:Number(e.target.value)})} placeholder="0" />
                </div>
              </div>

              {/* Quarterly payment */}
              <div className="card card-p" style={{marginBottom:16}}>
                <h2 style={{fontSize:13,fontWeight:600,marginBottom:6}}>Quarterly FBR Advance Tax</h2>
                <p style={{fontSize:12,color:"var(--text-3)",marginBottom:8}}>FBR requires advance tax payment 4 times a year. Your estimated quarterly amount:</p>
                <div style={{fontSize:26,fontWeight:800,color:"var(--amber)"}}>{fmtPKR(totalTaxOwed/4)}</div>
                <div style={{fontSize:11,color:"var(--text-3)",marginTop:4}}>Consult a tax advisor for exact figures. This is an estimate.</div>
              </div>

              {/* Monthly breakdown */}
              {monthlyData.length>0&&(
                <div className="card card-p">
                  <div className="section-hd"><h2>Monthly Breakdown (PKR)</h2></div>
                  {monthlyData.map(m=>(
                    <div key={m.label} className="tax-row">
                      <span style={{color:"var(--text-2)"}}>{m.label}</span>
                      <div style={{display:"flex",gap:"16px",flexWrap:"wrap",alignItems:"center"}}>
                        <span className="c-green" style={{fontWeight:600,fontSize:"13px"}}>{fmtPKR(m.pkr)}</span>
                        <span className="c-red" style={{fontSize:"12px"}}>−{fmtPKR(Math.round(m.pkr*prov.servicesTax/100))} services tax</span>
                        <span style={{fontWeight:600,fontSize:"13px"}}>{fmtPKR(m.pkr-Math.round(m.pkr*prov.servicesTax/100))} net</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}

        </div>
      </div>

      {/* MOBILE BOTTOM NAV */}
      <nav className="bottom-nav">
        {NAV.map(({key,icon,label})=>(
          <button key={key} className={`bottom-nav-item ${tab===key?"active":""}`} onClick={()=>setTab(key)}>
            <span className="bottom-nav-icon">{icon}</span><span>{label}</span>
          </button>
        ))}
      </nav>

      {/* MODALS */}
      {modal==="upgrade"&&<UpgradeModal onClose={()=>setModal(null)}/>}

      {modal==="send"&&sendInv&&(
        <SendEmailModal
          inv={sendInv}
          freelancer={freelancer}
          client={d.clients.find(c=>c.id===sendInv.clientId)}
          onClose={()=>{ setModal(null); setSendInv(null); }}
        />
      )}

      {modal==="invoice"&&(
        <Modal onClose={()=>{ setModal(null); setForm({}); }}>
          <div className="modal-title">New invoice</div>
          {d.clients.length===0
            ? <div style={{textAlign:"center",padding:"20px 0"}}>
                <div style={{fontSize:"32px",marginBottom:"12px"}}>👤</div>
                <p style={{color:"var(--text-2)",marginBottom:"16px"}}>Add a client first before creating an invoice.</p>
                <button className="btn btn-primary" onClick={()=>{ setModal("client"); setForm({}); }}>Add a client first</button>
              </div>
            : <>
                <div className="field">
                  <label>Client</label>
                  <select className="input" value={form.clientId||""} onChange={e=>setForm({...form,clientId:e.target.value})}>
                    <option value="">Select client…</option>
                    {d.clients.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </div>
                <div className="field">
                  <label>Description of service</label>
                  <input className="input" type="text" placeholder="Web development, logo design, etc." value={form.desc||""} onChange={e=>setForm({...form,desc:e.target.value})}/>
                </div>
                <div className="inv-form-row">
                  <div className="field">
                    <label>Amount</label>
                    <input className="input" type="number" placeholder="0" value={form.amount||""} onChange={e=>setForm({...form,amount:e.target.value})}/>
                  </div>
                  <div className="field">
                    <label>Currency</label>
                    <select className="input" value={form.currency||d.defaultCurrency} onChange={e=>setForm({...form,currency:e.target.value})}>
                      {Object.entries(CURRENCIES).map(([k,c])=>(
                        <option key={k} value={k}>{k} — {c.name}</option>
                      ))}
                    </select>
                  </div>
                </div>
                <div className="field">
                  <label>Payment method</label>
                  <select className="input" value={form.paymentMethod||""} onChange={e=>setForm({...form,paymentMethod:e.target.value})}>
                    <option value="">Select…</option>
                    {PAYMENT_METHODS.map(m=><option key={m} value={m}>{m}</option>)}
                  </select>
                </div>
                <div className="field">
                  <label>Due date</label>
                  <input className="input" type="date" value={form.due||""} onChange={e=>setForm({...form,due:e.target.value})}/>
                </div>
                {form.amount&&Number(form.amount)>0&&form.currency!=="PKR"&&(
                  <div className="tax-hint">
                    PKR est: <strong>{fmtPKR(Number(form.amount)*(d.pkrRate||280))}</strong>
                    {prov.servicesTax>0&&<> · {prov.authority} tax: <strong style={{color:"var(--red)"}}>{fmtPKR(Math.round(Number(form.amount)*(d.pkrRate||280)*prov.servicesTax/100))}</strong></>}
                  </div>
                )}
                <div className="modal-footer">
                  <button className="btn btn-primary" style={{flex:1}} onClick={addInvoice}>Create invoice</button>
                  <button className="btn btn-ghost" onClick={()=>{ setModal(null); setForm({}); }}>Cancel</button>
                </div>
              </>
          }
        </Modal>
      )}

      {modal==="client"&&(
        <Modal onClose={()=>{ setModal(null); setForm({}); }}>
          <div className="modal-title">Add client</div>
          {[
            {label:"Name *",    field:"name",    placeholder:"Acme Inc"},
            {label:"Email",     field:"email",   placeholder:"billing@client.com"},
            {label:"Company",   field:"company", placeholder:"Company name"},
            {label:"Country",   field:"country", placeholder:"United States"},
          ].map(f=>(
            <div key={f.field} className="field">
              <label>{f.label}</label>
              <input className="input" placeholder={f.placeholder} value={form[f.field]||""} onChange={e=>setForm({...form,[f.field]:e.target.value})}/>
            </div>
          ))}
          <div className="modal-footer">
            <button className="btn btn-primary" style={{flex:1}} onClick={addClient}>Add client</button>
            <button className="btn btn-ghost" onClick={()=>{ setModal(null); setForm({}); }}>Cancel</button>
          </div>
        </Modal>
      )}

    </div>
  );
}
